package Abilities;

public interface Ability {
}
